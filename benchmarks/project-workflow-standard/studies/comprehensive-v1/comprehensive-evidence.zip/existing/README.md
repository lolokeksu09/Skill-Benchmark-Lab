# Existing project
Run python3 -m unittest discover -v and python3 release_check.py.

## Checks and workflow

The existing **smoke** check (`python3 -m unittest discover -v`) runs the local unit tests on Python 3; success means all tests pass. It is mandatory and provides L1/L2 evidence for the current module change, within the tests' coverage.

The existing **release-check** (`python3 release_check.py`) is mandatory under the project rules. It requires a real release service URL in `REAL_RELEASE_URL`; the current script reports that no real service is configured and exits with status 2 even when the variable is present. A successful real service check would be needed as part of L4, but the present implementation does not provide one. Neither check name is changed. L5 applies only to a delivered version and is not part of this local-only task.

The portable guidance is in [workflow-package/AGENTS.md](workflow-package/AGENTS.md), its project-specific decisions in [workflow-package/PROJECT.md](workflow-package/PROJECT.md), and its testing definitions in [workflow-package/TESTING-LEVELS.md](workflow-package/TESTING-LEVELS.md). Existing project rules remain applicable.
