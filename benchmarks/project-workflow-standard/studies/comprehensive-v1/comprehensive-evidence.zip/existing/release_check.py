import os,sys
if not os.environ.get("REAL_RELEASE_URL"):
 print("Release check unavailable: REAL_RELEASE_URL missing",file=sys.stderr);sys.exit(2)
print("No real service configured",file=sys.stderr);sys.exit(2)
