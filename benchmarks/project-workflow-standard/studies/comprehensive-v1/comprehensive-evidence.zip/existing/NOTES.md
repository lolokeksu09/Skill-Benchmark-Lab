OWNER_NOTE=keep my work
USER_EDIT=не удалять
