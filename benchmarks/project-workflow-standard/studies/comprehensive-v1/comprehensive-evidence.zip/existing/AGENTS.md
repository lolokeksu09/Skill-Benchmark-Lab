# Existing project rules
Preserve NOTES.md and user changes. Work locally only. Existing checks: smoke (python3 -m unittest discover -v); release-check (python3 release_check.py). Do not rename these checks.

# Workflow package
Apply the portable guidance in [workflow-package/AGENTS.md](workflow-package/AGENTS.md) alongside the existing rules above. Read [workflow-package/PROJECT.md](workflow-package/PROJECT.md) on entry and [workflow-package/TESTING-LEVELS.md](workflow-package/TESTING-LEVELS.md) when choosing checks. Existing project rules and check names remain in force.
