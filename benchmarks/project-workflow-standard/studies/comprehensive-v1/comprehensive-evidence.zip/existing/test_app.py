import unittest
from app import total


class T(unittest.TestCase):
    def test_total(self):
        self.assertEqual(total([2, 3]), 5)

    def test_empty_total(self):
        self.assertEqual(total([]), 0)

    def test_total_with_negative_and_fractional_numbers(self):
        self.assertEqual(total([-2, 0.5, 3]), 1.5)
