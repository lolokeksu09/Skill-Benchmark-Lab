import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


class NotesCLI(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.script = self.directory / "notes.py"
        shutil.copy2(Path(__file__).resolve().parents[1] / "notes.py", self.script)
        self.data = self.directory / "notes.json"

    def run_cli(self, *args):
        return subprocess.run([sys.executable, str(self.script), *args], cwd=self.directory.parent,
                              text=True, capture_output=True)

    def test_empty_and_persistent_order(self):
        self.assertEqual(json.loads(self.run_cli("list").stdout), [])
        for text in (" первая ", "вторая"):
            self.assertEqual(self.run_cli("add", text).returncode, 0)
        result = self.run_cli("list")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout), [" первая ", "вторая"])
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")), [" первая ", "вторая"])

    def test_empty_text_rejected_without_changing_data(self):
        self.assertEqual(self.run_cli("add", "existing").returncode, 0)
        before = self.data.read_bytes()
        for text in ("", " \t\n"):
            self.assertNotEqual(self.run_cli("add", text).returncode, 0)
            self.assertEqual(self.data.read_bytes(), before)

    def test_invalid_data_rejected(self):
        self.data.write_text("{bad", encoding="utf-8")
        for command in (("list",), ("add", "new")):
            result = self.run_cli(*command)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(self.data.read_text(encoding="utf-8"), "{bad")


if __name__ == "__main__":
    unittest.main()
