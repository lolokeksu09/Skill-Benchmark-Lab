#!/usr/bin/env python3
"""Store simple notes beside this program."""

import argparse
import json
from pathlib import Path

NOTES_FILE = Path(__file__).resolve().with_name("notes.json")


def main():
    parser = argparse.ArgumentParser(description="Add and list local notes.")
    commands = parser.add_subparsers(dest="command", required=True)
    add = commands.add_parser("add", help="add a nonempty note")
    add.add_argument("text", metavar="TEXT")
    commands.add_parser("list", help="print notes as a JSON array")
    args = parser.parse_args()

    if args.command == "add" and not args.text.strip():
        parser.error("TEXT must not be empty or whitespace")

    try:
        if NOTES_FILE.exists():
            notes = json.loads(NOTES_FILE.read_text(encoding="utf-8"))
            if not isinstance(notes, list) or not all(isinstance(note, str) for note in notes):
                raise ValueError("notes.json must contain an array of strings")
        else:
            notes = []
        if args.command == "add":
            notes.append(args.text)
            NOTES_FILE.write_text(json.dumps(notes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        else:
            print(json.dumps(notes, ensure_ascii=False))
    except (OSError, ValueError) as exc:
        parser.exit(1, f"Error: {exc}\n")


if __name__ == "__main__":
    main()
